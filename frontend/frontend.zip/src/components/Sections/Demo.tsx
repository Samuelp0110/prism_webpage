import type { FC } from "react";

const Demo: FC = () => {
  return (
    <section>
      <div>Demo Section</div>
    </section>
  );
};

export default Demo;
