import type { FC } from "react";

const AboutCompany: FC = () => {
  return (
    <section>
      <div>About Company Section</div>
    </section>
  );
};

export default AboutCompany;
