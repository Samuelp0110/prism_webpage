import type { FC } from "react";
import { useRef } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import * as THREE from "three";

type IcoProps = {
  /** Wireframe color */
  color?: string; // default: "#b7ff00"
  /** Radius and subdivision detail (matches THREE.IcosahedronGeometry) */
  radius?: number; // default: 20
  detail?: number; // default: 4
  /** Auto-rotate the mesh (off = static, like the original) */
  autoRotate?: boolean; // default: false
  rotationSpeed?: number; // radians/sec (if autoRotate)
  /** Optional class for the outer container (controls size) */
  className?: string;
  /** Canvas background color (CSS color) */
  background?: string | null; // default: null (transparent)
};



const IcoMesh: FC<Omit<IcoProps, "className" | "background">> = ({
  color = "#b7ff00",
  radius = 20,
  detail = 4,
  autoRotate = false,
  rotationSpeed = 0.6,
}) => {
  const meshRef = useRef<THREE.Mesh | null>(null);

  useFrame((_, delta) => {
    if (!autoRotate || !meshRef.current) return;
    meshRef.current.rotation.y += rotationSpeed * delta;
    meshRef.current.rotation.x += rotationSpeed * 0.4 * delta;
  });

  return (
    <mesh ref={meshRef}>
      <icosahedronGeometry args={[radius, detail]} />
      <meshBasicMaterial
        color={color}
        wireframe
      />
    </mesh>
  );
};

const Icosahedron: FC<IcoProps> = ({
  className,
  background = null,
  ...meshProps
}) => {
  return (
    <div
      className={className}
      style={{ position: "relative", width: "100%", height: "100%" }}
    >
      <Canvas
        dpr={[1, 2]}
        camera={{ fov: 30, position: [0, 0, 100] }}
        onCreated={({ gl, scene }) => {
          if (background === null) gl.setClearAlpha(0);
          else gl.setClearColor(new THREE.Color(background), 1);
        }}
      >
        <IcoMesh {...meshProps} />
      </Canvas>
    </div>
  );
};

export default Icosahedron;
