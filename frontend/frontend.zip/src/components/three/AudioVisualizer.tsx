// AudioVisualizer.tsx
import {
  useRef,
  useEffect,
  useMemo,
  useState,
  type RefObject,
  type FC,
} from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls, shaderMaterial, useAspect } from "@react-three/drei";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass";
import { OutputPass } from "three/examples/jsm/postprocessing/OutputPass";
import { extend, useFrame as useRenderFrame } from "@react-three/fiber";
import glsl from "babel-plugin-glsl/macro";

extend({ EffectComposer, RenderPass, UnrealBloomPass, OutputPass });

type Props = {
  audioRef: RefObject<HTMLAudioElement>;
  radius?: number;
  detail?: number;
  color?: { red: number; green: number; blue: number };
  bloom?: { strength: number; threshold: number; radius: number };
  className?: string;
};

// Custom Shader Material
const IcoMaterial = shaderMaterial(
  {
    u_time: 0,
    u_frequency: 0,
    u_red: 1,
    u_green: 1,
    u_blue: 1,
  },
  glsl`
    uniform float u_time;
    uniform float u_frequency;
    varying vec3 vNormal;

    // Perlin Noise Implementation
    // (Using minimal example for brevity)
    float pnoise(vec3 pos) {
      return fract(sin(dot(pos.xyz ,vec3(12.9898,78.233, 151.7182))) * 43758.5453);
    }

    void main() {
      float noise = pnoise(position + vec3(u_time));
      float displacement = (u_frequency / 30.0) * noise;
      vec3 newPosition = position + normal * displacement;
      vNormal = normal;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(newPosition, 1.0);
    }
  `,
  glsl`
    uniform float u_red;
    uniform float u_green;
    uniform float u_blue;
    varying vec3 vNormal;

    void main() {
      gl_FragColor = vec4(u_red, u_green, u_blue, 1.0);
    }
  `
);

extend({ IcoMaterial });

const VisualizerMesh: FC<{
  analyser: THREE.AudioAnalyser;
  radius: number;
  detail: number;
  color: { red: number; green: number; blue: number };
}> = ({ analyser, radius, detail, color }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const matRef = useRef<any>(null);
  const clock = useMemo(() => new THREE.Clock(), []);

  useFrame(() => {
    if (matRef.current && analyser) {
      matRef.current.u_time = clock.getElapsedTime();
      matRef.current.u_frequency = analyser.getAverageFrequency();
      matRef.current.u_red = color.red;
      matRef.current.u_green = color.green;
      matRef.current.u_blue = color.blue;
    }
  });

  return (
    <mesh ref={meshRef}>
      <icosahedronGeometry args={[radius, detail]} />
      {/* @ts-ignore */}
      <icoMaterial ref={matRef} />
    </mesh>
  );
};

const Effects: FC<{
  bloom: { strength: number; threshold: number; radius: number };
}> = ({ bloom }) => {
  const { scene, camera, gl, size } = useThree();
  const composer = useRef<EffectComposer>();

  useEffect(() => {
    const renderScene = new RenderPass(scene, camera);
    const bloomPass = new UnrealBloomPass(
      new THREE.Vector2(size.width, size.height),
      bloom.strength,
      bloom.radius,
      bloom.threshold
    );
    const outputPass = new OutputPass();

    composer.current = new EffectComposer(gl);
    composer.current.addPass(renderScene);
    composer.current.addPass(bloomPass);
    composer.current.addPass(outputPass);
  }, [scene, camera, gl, size, bloom]);

  useRenderFrame(() => {
    composer.current?.render();
  }, 1);

  return null;
};

const AudioVisualizer: FC<Props> = ({
  audioRef,
  radius = 4,
  detail = 30,
  color = { red: 1, green: 1, blue: 1 },
  bloom = { strength: 0.5, threshold: 0.5, radius: 0.8 },
  className = "",
}) => {
  const [analyser, setAnalyser] = useState<THREE.AudioAnalyser | null>(null);

  useEffect(() => {
    if (!audioRef?.current) return;

    const listener = new THREE.AudioListener();
    const sound = new THREE.Audio(listener);
    const context = new (window.AudioContext ||
      (window as any).webkitAudioContext)();
    const src = context.createMediaElementSource(audioRef.current);
    const analyserNode = new THREE.AudioAnalyser(sound, 32);

    sound.setMediaElementSource(audioRef.current);
    camera.add(listener); // Needed to route audio

    setAnalyser(analyserNode);
  }, [audioRef]);

  return (
    <div className={`w-full h-full relative ${className}`}>
      <Canvas camera={{ position: [0, -2, 14], fov: 45 }}>
        <ambientLight />
        {analyser && (
          <VisualizerMesh
            analyser={analyser}
            radius={radius}
            detail={detail}
            color={color}
          />
        )}
        <Effects bloom={bloom} />
        <OrbitControls />
      </Canvas>
    </div>
  );
};

export default AudioVisualizer;
